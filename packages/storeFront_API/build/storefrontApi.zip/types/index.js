"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderStatus = void 0;
var OrderStatus;
(function (OrderStatus) {
    OrderStatus["ACTIVE"] = "active";
    OrderStatus["COMPLETE"] = "complete";
    OrderStatus["ALL"] = "all";
})(OrderStatus = exports.OrderStatus || (exports.OrderStatus = {}));
